
<footer class="footer">
    <div class="footer-body" style="display: block;">
        <div class="text-center">
            ©<script>document.write(new Date().getFullYear())</script>  {{env('APP_NAME')}}
        </div>
    </div>
</footer>

