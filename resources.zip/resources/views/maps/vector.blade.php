<x-app-layout :assets="$assets ?? []">
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <div class="header-title">
                    <h4 class="card-title">Vector</h4>
                </div>
            </div>
            <div class="card-body">
                <div id="chart-map-column-04" class="custom-chart leaflet-container leaflet-touch leaflet-fade-anim leaflet-grab leaflet-touch-drag leaflet-touch-zoom" tabindex="0" style="position: relative;">

                </div>
            </div>
        </div>
    </div>
</div>
</x-app-layout>
